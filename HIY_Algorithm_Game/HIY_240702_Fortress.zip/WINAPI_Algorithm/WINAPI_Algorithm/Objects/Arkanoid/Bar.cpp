#include "pch.h"
#include "Bar.h"

Bar::Bar()
{
}

Bar::~Bar()
{
}

void Bar::Update()
{
}

void Bar::Render(HDC hdc)
{
}
