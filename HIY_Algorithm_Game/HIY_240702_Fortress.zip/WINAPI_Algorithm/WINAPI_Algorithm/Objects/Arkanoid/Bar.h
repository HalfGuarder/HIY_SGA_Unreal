#pragma once
class Bar
{
public:
	Bar();
	~Bar();

	void Update();
	void Render(HDC hdc);

private:

};

