#pragma once

#define RED				RGB(255, 0 , 0)
#define GREEN			RGB(0, 255, 0)
#define BLUE			RGB(0, 0, 255)

#define PANTON			RGB(255, 103, 32)
#define SKYCOLOR		RGB(123, 196, 196)
#define MINT			RGB(102, 255, 204)

#define LERP(s, e, t)	s + (e - s) * t